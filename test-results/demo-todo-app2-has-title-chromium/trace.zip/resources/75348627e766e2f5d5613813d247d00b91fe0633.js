YUI.add("selector",function(e,t){},"patched-v3.19.2",{requires:["selector-native"]});
