AUI().ready((function(){})),Liferay.Portlet.ready((function(e,n){})),Liferay.on("allPortletsReady",(function(){}));
//# sourceMappingURL=main.js.map
